def b(self,a1):
    from tkinter import ttk
    import tkinter
    root = tkinter.Tk()

    a1.tkraise()