from tkinter import *
from Hauptmenü import Toplevel1 as t0
from Abmelden import Toplevel1 as t1
from Anmelden import Toplevel1 as t2

def call_Abmelden():
    t1()


def call_Anmelden():
    t2()
def call_Hauptmenu():
    t0()