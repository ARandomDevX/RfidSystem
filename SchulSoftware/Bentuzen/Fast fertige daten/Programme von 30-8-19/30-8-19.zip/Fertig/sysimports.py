from Hauptmenü import Toplevel1 as T1
from Anmelden import Toplevel1 as T2
from Abmelden import Toplevel1 as T3
