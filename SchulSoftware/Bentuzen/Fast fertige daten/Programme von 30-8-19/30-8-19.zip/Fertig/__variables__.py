from tkinter import StringVar
from tkinter import *
class var  :
    def __init__(self):
        radiovar = ''
        return radiovar
root = Tk()
ortvar = StringVar()
ortvar.set(None)

