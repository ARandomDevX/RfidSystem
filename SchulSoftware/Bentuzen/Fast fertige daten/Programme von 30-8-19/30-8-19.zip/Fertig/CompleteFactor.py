from Anmelden import Toplevel1 as t1
from Abmelden import Toplevel1 as t2
from Hauptmenü import Toplevel1 as t3
from Sonstiges import Toplevel1 as t4
from Notfall import Toplevel1 as t5
from unknown import Toplevel1 as t6

from datetime import *


t3(frame1=t1())